package com.cryptopulse.stock_dashboard.controller;

import com.cryptopulse.stock_dashboard.model.Market;
import com.cryptopulse.stock_dashboard.service.MarketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/markets")
@CrossOrigin(origins = "http://localhost:4200") 
public class MarketController {

    @Autowired
    private MarketService marketService;

    @GetMapping
    public List<Market> getMarkets() {
        return marketService.getAllMarkets();
    }

    // Changed Long id to String id
    @PostMapping("/{id}/vote")
    public Market castVote(@PathVariable String id, @RequestParam String type) {
        return marketService.registerVote(id, type);
    }
}